import mainpack as mp
import mainpack.sudpack2 as ms
from mainpack.sudpack2 import arthamatic as ar
print(mp.main)
print(mp.mainpackdemo())



print(ms.sub)
print(ms.subpackdemo())


print(ar.add(4,5))
print(ar.sub(10,5))