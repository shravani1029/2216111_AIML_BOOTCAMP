main= "demonstrats main package"
def mainpackdemo():
    return "main-pack demonstration"