def add(x,y):
    return x+y


def sub(x,y):
    return x-y


def mul(x,y):
    return x*y
